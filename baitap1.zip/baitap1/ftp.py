from ftplib import FTP, FTP_PORT, FTP_TLS
import socket


def send_command(ftp, command):
    
    ftp.sendcmd(command)


def send_epsv_command(ftp):
    response = ftp.sendcmd('EPSV')
    return response


def send_pasv_command(ftp):
    response = ftp.sendcmd('PASV')
    return response


def parse_pasv_response(response):
    start = response.find('(') + 1
    end = response.find(')')
    address = response[start:end]
    parts = address.split(',')
    ip_address = '.'.join(parts[:4])
    port = (int(parts[4]) << 8) + int(parts[5])
    return ip_address, port


def upload_file(hostname, username, password, file_path):
    ftp = FTP()
    ftps_mode = False
    try:
        ftp = FTP_TLS(hostname)
        ftps_mode = True
    except socket.gaierror:
        ftp.connect(hostname)

    ftp.login(username, password)

    if ftps_mode:
        ftp.prot_p()
    elif ftp.has_ext('EPSV'):
        send_command(ftp, 'EPSV')
    else:
        send_command(ftp, 'PASV')

    with open(file_path, 'rb') as file:
        if ftps_mode:
            ftp.storbinary('STOR ' + file_path, file)
        else:
            response = send_pasv_command(ftp)
            ip_address, port = parse_pasv_response(response)
            data_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            data_socket.connect((ip_address, port))
            ftp.storbinary('STOR ' + file_path, file, socket=data_socket)
            data_socket.close()

    ftp.quit()



hostname = 'ftp.20187252.com'
username = 'longmh '
password = 'long123'
file_path = 'config.txt'  

upload_file(hostname, username, password, file_path)
